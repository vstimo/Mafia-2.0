package mafia.gui;

public interface TextSenderListener {
    void sendText();
}
