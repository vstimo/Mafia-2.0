package mafia.gui;

public interface ButtonClickListener {
    void submitButtonClicked();
    void readyButtonClicked();
}